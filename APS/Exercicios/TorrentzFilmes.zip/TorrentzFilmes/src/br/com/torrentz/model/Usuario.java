package br.com.torrentz.model;

public class Usuario {

    private int iden;
    private String nome;
    private String cpf;
    private String email;
    private String senha;
    private Contrato contrato;
    private Plano plano;

    public int getIden() {
        return iden;
    }

    public void setIden(int iden) {
        this.iden = iden;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Contrato getContrato() {
        return contrato;
    }

    public void setContrato(Contrato contrato) {
        this.contrato = contrato;
    }

    public Plano getPlano() {
        return plano;
    }

    public void setPlano(Plano plano) {
        this.plano = plano;
    }

    @Override
    public String toString() {
        return "Usuario{" + "iden=" + iden + ", nome=" + nome + ", cpf="
                + cpf + ", email=" + email + ", senha=" + senha
                + ", contrato=" + contrato + ", plano=" + plano + '}';
    }

}
