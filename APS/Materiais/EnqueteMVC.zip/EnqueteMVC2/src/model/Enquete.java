/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.text.DecimalFormat;

/**
 *
 * @author elisabete.hato
 */
public class Enquete {
    String[] opcao = new String[4];
    int[] qtdeVotos = new int[4];
    int totalVotos;
    
    public void inicializarValores(){
        opcao[0] = "Opção 1";
        opcao[1] = "Opção 2";
        opcao[2] = "Opção 3";
        opcao[3] = "Opção 4";
        qtdeVotos[0] = 0;
        qtdeVotos[1] = 0;
        qtdeVotos[2] = 0;
        qtdeVotos[3] = 0;
        totalVotos = 0;
    }
    
    public void votar(int opcao){
        qtdeVotos[opcao]++;
        totalVotos++;
    }
    
    public String gerarResultado(){
        DecimalFormat df = new DecimalFormat("#,###.00");

        double percentual = 0.0;
        String resultado = "Qtde Votos: \n";
        
        for(int i=0; i < 4; i++){
            resultado = resultado + opcao[i] + ": " + qtdeVotos[i] + "\n";
        }
        resultado = resultado + "\n";
        resultado = resultado + "Percentual:\n";
        for(int i=0; i < 4; i++){
            percentual = ((double)qtdeVotos[i] / (double)totalVotos) * 100.00;
            resultado = resultado + opcao[i] + ": " + df.format(percentual) + "%\n";
        }
        return resultado;
    }
    
}
