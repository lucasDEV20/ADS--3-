package lista1_Pilha_Vetores.ex03;

public class PilhaPessoa {

    private int tamanho;
    private Pessoa[] array;
    private int topo = -1;

    public PilhaPessoa() { 
        this(10); // procura o construtor com parametros da classe
    } 

    public PilhaPessoa(int tamanho) {
        if (tamanho <= 0) {
            throw new RuntimeException("tamanho inv�lido!");
        }
        this.tamanho = tamanho;
        array = new Pessoa[tamanho];
    }

    public void inserir(Pessoa elemento) {
        if (estaCheia()) {
            throw new RuntimeException("Pilha cheia");
        }
        array[++topo] = elemento;
    }

    public void retirar() {
        if (estaVazia()) {
            throw new RuntimeException("A pilha est� vazia");
        }
        topo--;
    }

    public boolean estaVazia() {
        return topo == -1;
    }

    public boolean estaCheia() {
        return topo == (tamanho - 1);
    }

    public int qtdElementos() {
        return topo + 1;
    }

    public Pessoa consultar() {
        return array[topo];
    }

    public void esvaziarPilha() {
        topo = -1;
    }

    @Override
    public String toString() {
        return "Pilha_vet_objetos{" + "array=" + array + '}';
    }
    
    
    
}
