package lista1_Pilha_Vetores.ex03;

import java.util.Scanner;

public class Main_Ex03 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int opcao = 0;
        PilhaPessoa pilha = new PilhaPessoa(4);

        while (opcao != 5) {

            imprimirMenu();
            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    empilharObjeto(sc, pilha);
                    break;

                case 2:
                    desempilharObjeto(pilha);
                    break;

                case 3:
                    imprimirPilha(pilha);
                    break;

                case 4:
                    mostrarObjeto(pilha);
                    break;

                case 5:
                    System.out.println("[[------ Encerrando ------]]");
                    break;

                default:
                    System.out.println("[[------ Op��o inv�lida ------]]");
                    break;
            }
        }
    }

    public static void imprimirMenu() {
        System.out.println("\n"
                + "1 - Empilhar um objeto Pessoa\n"
                + "2 - Desempilhar um objeto Pessoa\n"
                + "3 - Imprimir toda a pilha\n"
                + "4 - Consultar/mostrar o objeto Pessoa do topo da pilha (sem remover)\n"
                + "5 - Sair\n");
    }

    public static void empilharObjeto(Scanner sc, PilhaPessoa pilha) {
        sc.nextLine();

        if (pilha.estaCheia()) {
            System.out.println("[[------ pilha est� cheia! ------]]");
        } else {
            Pessoa pessoa = new Pessoa();

            System.out.println("Nome:");
            pessoa.setNome(sc.nextLine());

            System.out.println("Endere�o:");
            pessoa.setEndereco(sc.nextLine());

            System.out.println("Telefone:");
            pessoa.setTelefone(sc.nextInt());

            pilha.inserir(pessoa);
            System.out.println("\n[[------ Pessoa inclusa na pilha ------]]");

        }
    }

    public static void desempilharObjeto(PilhaPessoa pilha) {
        if (pilha.estaVazia()) {
            System.out.println("\n[[------ Pilha est� vazia ------]]");
        } else {
            pilha.retirar();
            System.out.println("[[------ Elemento desempilhado ------]]");
        }
    }

    public static void mostrarObjeto(PilhaPessoa pilha) {
        if (pilha.estaVazia()) {
            System.out.println("\n[[------ Pilha est� vazia ------]]");
        } else {
            System.out.println("\n");
            System.out.println(pilha.consultar());
        }
    }

    public static void imprimirPilha(PilhaPessoa pilha) {

        if (pilha.estaVazia()) {
            System.out.println("[[------ Pilha est� vazia ------]]");

        } else {
            System.out.println("\n");
            PilhaPessoa novaPilha = new PilhaPessoa(pilha.qtdElementos());

            while (!pilha.estaVazia()) {
                Pessoa pessoa = pilha.consultar();
                novaPilha.inserir(pessoa);
                System.out.println(pessoa);
                pilha.retirar();
            }

            // recoloca de volta na pilha
            while (!novaPilha.estaVazia()) {
                pilha.inserir(novaPilha.consultar());
                novaPilha.retirar();
            }
        }
    }
}
