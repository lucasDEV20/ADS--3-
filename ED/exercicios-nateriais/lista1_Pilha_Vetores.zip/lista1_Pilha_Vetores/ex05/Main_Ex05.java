package lista1_Pilha_Vetores.ex05;

import java.util.Scanner;

public class Main_Ex05 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long n, aux;
        int qtdElementos = 0;

// 1.0 Entrada usu�rio        
        System.out.println("Informe N:");
        n = sc.nextInt();

// 2.0 Identificar qtd de elementos da pilha
        aux = n;
        while (aux != 0) {
            aux = aux / 10;
            qtdElementos++;
        }

// 3.0 Algor�timo para verificar se � pal�ndromo
        Pilha_Ex05 pilha = new Pilha_Ex05(qtdElementos);
        aux = n;
        System.out.println("-----------------------------");

        while (!pilha.estaCheia()) {
            pilha.inserir(aux % 10);
            aux = aux / 10;
        }

        boolean verificador = true;
        aux = n;
        for (int i = 0; i < pilha.qtdElementos() / 2 && verificador; i++) {
            if (aux % 10 != pilha.consultarElementoTopo()) {
                verificador = false;
            } else {
                aux = aux / 10;
                pilha.retirar();
            }
        }

        if (verificador) {
            System.out.println(n + " � pal�ndromo");
        } else {
            System.out.println(n + " N�O � pal�ndromo");
        }
    }
}
