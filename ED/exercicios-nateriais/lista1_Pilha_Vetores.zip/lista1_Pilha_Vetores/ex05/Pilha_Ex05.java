package lista1_Pilha_Vetores.ex05;

public class Pilha_Ex05 {

    private int tamanho;
    private long[] array;
    private int topo = -1;


    public Pilha_Ex05(int tamanho) {
        if (tamanho <= 0) {
            throw new RuntimeException("tamanho inv�lido");
        }
        this.tamanho = tamanho;
        array = new long[tamanho];
    }

    public boolean estaCheia() {
        return topo == (tamanho - 1);
    }

    public boolean estaVazia() {
        return topo == -1;
    }

    public void inserir(long elemento) {
        if (estaCheia()) {
            throw new RuntimeException("Pilha est� cheia!");
        }
        array[++topo] = elemento;
    }

    public void retirar() {
        if (estaVazia()) {
            throw new RuntimeException("Pilha est� vazia!");
        }
        topo--;
    }

    public int qtdElementos() {
        return topo + 1;
    }

    public long consultarElementoTopo() {
        return array[topo];
    }

    public void esvaziarPilha() {
        topo = -1;
    }   
    
}
