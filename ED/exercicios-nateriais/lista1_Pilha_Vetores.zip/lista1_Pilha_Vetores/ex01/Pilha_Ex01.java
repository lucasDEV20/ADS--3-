package lista1_Pilha_Vetores.ex01;

public class Pilha_Ex01 {

    private int tamanho;
    private int[] array;
    private int topo = -1;

    public Pilha_Ex01() {
        this(5); // procura o construtor com parametros int da classe
    }

    public Pilha_Ex01(int tamanho) {
        if (tamanho <= 0) {
            throw new RuntimeException("tamanho inv�lido");
        }
        this.tamanho = tamanho;
        array = new int[tamanho];
    }

    public boolean estaCheia() {
        return topo == (tamanho - 1);
    }

    public boolean estaVazia() {
        return topo == -1;
    }

    public void inserir(int elemento) {
        if (estaCheia()) {
            throw new RuntimeException("Pilha est� cheia!");
        }
        array[++topo] = elemento;
    }

    public void retirar() {
        if (estaVazia()) {
            throw new RuntimeException("Pilha est� vazia!");
        }
        topo--;
    }

    public int qtdElementos() {
        return topo + 1;
    }

    public int consultarElementoTopo() {
        return array[topo];
    }

    public void esvaziarPilha() {
        topo = -1;
    }
}
