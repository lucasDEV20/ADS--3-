package lista1_Pilha_Vetores.ex01;

import java.util.Random;
import java.util.Scanner;

public class Main_Ex01 {

    public static void main(String[] args) {

//1.0 Estanciando e inserindo elementos na pilha 
        Pilha_Ex01 pilha = new Pilha_Ex01();
        Random rd = new Random();
        Scanner sc = new Scanner(System.in);
        while (!pilha.estaCheia()) {
            int auxn = rd.nextInt(100);
            pilha.inserir(auxn);
        }
        imprimirPilha(pilha);

//2.0 Retirando elementos da pilha
        do {
            System.out.printf("\n\nInforme valor a ser retirado: ");
            int nRetirar;
            nRetirar = sc.nextInt();
            retiraElemento(nRetirar, pilha);
            imprimirPilha(pilha);
        } while (!pilha.estaVazia());
    }

    public static void retiraElemento(int elemento, Pilha_Ex01 pilha) {
        Pilha_Ex01 pAux = new Pilha_Ex01(pilha.qtdElementos());
        while (!pilha.estaVazia()
                && elemento != pilha.consultarElementoTopo()) {
            pAux.inserir(pilha.consultarElementoTopo());
            pilha.retirar();
        }
        if (!pilha.estaVazia()) {
            pilha.retirar();
        }
        while (!pAux.estaVazia()) {
            pilha.inserir(pAux.consultarElementoTopo());
            pAux.retirar();
        }
    }

    public static void imprimirPilha(Pilha_Ex01 pilha) {

        if (pilha.estaVazia()) {
            System.out.println("[[---- Pilha est� vazia ----]]");
        } else {
            Pilha_Ex01 novaPilha = new Pilha_Ex01(pilha.qtdElementos());

            int pos = pilha.qtdElementos() - 1;

            System.out.println("Pos\tElemento");
            while (!pilha.estaVazia()) {
                int n = pilha.consultarElementoTopo();
                novaPilha.inserir(n);
                System.out.println(" " + pos + "\t   " + n);
                pilha.retirar();
                pos--;
            }
            // recoloca de volta na pilha
            while (!novaPilha.estaVazia()) {
                pilha.inserir(novaPilha.consultarElementoTopo());
                novaPilha.retirar();
            }
        }
    }
}
