package lista1_Pilha_Vetores.ex02;

import java.util.Scanner;

public class Main_Ex02 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n, base, aux;

// 1.0 Entradas usu�rio   
        do {
            System.out.println("Informe N (maior que 0):");
            n = sc.nextInt();
        } while (n <= 0);

        do {
            System.out.println("Informe a Base(2, 8 ou 16):");
            base = sc.nextInt();
        } while (base != 2 && base != 8 && base != 16);

// 2.0 convers�o e impress�o
        aux = n;
        System.out.println("-----------------------------");
        System.out.print(n + " na base " + base + " � = ");
        System.out.println(converterBases(aux, base));
        System.out.println("");
    }

    public static String converterBases(int aux, int base) {
        int qtdElementos = 0;
        int aux2 = aux;
        
        // identifica qtd de elementos para pilha
        while (aux2 != 0) {
            aux2 = aux2 / base;
            qtdElementos++;
        }
        
        // inst�ncia obj pilha
        Pilha_Ex02 pilha = new Pilha_Ex02(qtdElementos);

        // preenche pilha com os restos das divis�es
        while (!pilha.estaCheia()) {
            pilha.inserir(aux % base);
            aux = aux / base;
        }
        // trata sa�da para bases 2,8 e 16
        String saida = "";
        String letras = "0123456789ABCDEF";
        while (!pilha.estaVazia()) {
            int nTopo = pilha.consultarElementoTopo();
            saida += letras.charAt(nTopo);
            pilha.retirar();
        }
        return saida;
    }
}
