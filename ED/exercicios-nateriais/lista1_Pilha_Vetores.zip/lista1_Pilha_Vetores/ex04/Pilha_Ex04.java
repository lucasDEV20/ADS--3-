package lista1_Pilha_Vetores.ex04;

public class Pilha_Ex04 {

    private int tamanho;
    private char[] array;
    private int topo = -1;

    public Pilha_Ex04() {
        this(5); // procura o construtor com parametros int da classe
    }

    public Pilha_Ex04(int tamanho) {
        if (tamanho <= 0) {
            throw new RuntimeException("tamanho inv�lido");
        }
        this.tamanho = tamanho;
        array = new char[tamanho];
    }

    public boolean estaCheia() {
        return topo == (tamanho - 1);
    }

    public boolean estaVazia() {
        return topo == -1;
    }

    public void inserir(char elemento) {
        if (estaCheia()) {
            throw new RuntimeException("Pilha est� cheia!");
        }
        array[++topo] = elemento;
    }

    public void retirar() {
        if (estaVazia()) {
            throw new RuntimeException("Pilha est� vazia!");
        }
        topo--;
    }

    public int qtdElementos() {
        return topo + 1;
    }

    public char consultarElementoTopo() {
        return array[topo];
    }

    public void esvaziarPilha() {
        topo = -1;
    }
}
