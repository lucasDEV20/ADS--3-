package lista1_Pilha_Vetores.ex04;

public class Main_Ex04 {

    public static void main(String[] args) {
        Pilha_Ex04 pilha = new Pilha_Ex04();
        pilha.inserir('A');
        pilha.inserir('B');
        pilha.inserir('C');
        pilha.inserir('D');
        pilha.inserir('E');
        System.out.println(pilha.consultarElementoTopo());
    }
}
