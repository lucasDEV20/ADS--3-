/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package projetoDecoradorCelular;

/**
 *
 * @author eugenio
 */
// classe Decorator
public abstract class Acessorio extends Celular {
    public abstract String getDescricao();
    
}
