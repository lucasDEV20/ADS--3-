/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoDecoradorTipoDeMusica;

/**
 *
 * @author Computador
 */
public class FoneSemFio extends Celular {
    public Celular smartphone;
    public FoneSemFio(Celular smartphone) {
        this.smartphone = smartphone;
    }
    public String getDescricao(){
        return smartphone.getDescricao() + ", Fone Sem fio";
    }
    
    public double preco(){
        return 450 + smartphone.preco();
    }
    
}
