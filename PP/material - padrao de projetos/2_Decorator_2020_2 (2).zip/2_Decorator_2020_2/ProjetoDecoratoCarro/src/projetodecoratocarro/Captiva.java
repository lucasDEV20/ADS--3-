/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package projetodecoratocarro;

/**
 *
 * @author eugenio
 */
public class Captiva extends Carro {

    public Captiva(){
        descricao = "Captiva Sport 2.4";
    }
    public double preco(){
        return 105000.00;
    }
}
