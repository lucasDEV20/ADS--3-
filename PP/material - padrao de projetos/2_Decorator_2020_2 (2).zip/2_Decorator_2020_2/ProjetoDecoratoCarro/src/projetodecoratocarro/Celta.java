/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package projetodecoratocarro;

/**
 *
 * @author eugenio
 */
public class Celta extends Carro{
    public Celta(){
        descricao = "Celta LT";
    }
    public double preco(){
        return 28000.00;
    }

}
